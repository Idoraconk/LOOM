import time
import sys
import os

os.system('cls')
line_1 = "$$\      $$\ $$$$$$$$\ $$\       $$$$$$\   $$$$$$\  $$\      $$\ $$$$$$$$\ "
line_2 = "$$ | $\  $$ |$$  _____|$$ |     $$  __$$\ $$  __$$\ $$$\    $$$ |$$  _____|"
line_3 = "$$ |$$$\ $$ |$$ |      $$ |     $$ /  \__|$$ /  $$ |$$$$\  $$$$ |$$ |      "
line_4 = "$$ $$ $$\$$ |$$$$$\    $$ |     $$ |      $$ |  $$ |$$\$$\$$ $$ |$$$$$\    "
line_5 = "$$$$  _$$$$ |$$  __|   $$ |     $$ |      $$ |  $$ |$$ \$$$  $$ |$$  __|   "
line_6 = "$$$  / \$$$ |$$ |      $$ |     $$ |  $$\ $$ |  $$ |$$ |\$  /$$ |$$ |      "
line_7 = "$$  /   \$$ |$$$$$$$$\ $$$$$$$$\\$$$$$$  | $$$$$$  |$$ | \_/ $$ |$$$$$$$$\ "
line_8 = "\__/     \__|\________|\________|\______/  \______/ \__|     \__|\________|" 
for x in line_1:
    print(x, end='')
    sys.stdout.flush()
    time.sleep(0.01)
print("")
for x2 in line_2:
    print(x2, end='')
    sys.stdout.flush()
    time.sleep(0.01)
print("")
for x3 in line_3:
    print(x3, end='')
    sys.stdout.flush()
    time.sleep(0.01)
print("")
for x4 in line_4:
    print(x4, end='')
    sys.stdout.flush()
    time.sleep(0.01)
print("")
for x5 in line_5:
    print(x5, end='')
    sys.stdout.flush()
    time.sleep(0.01)
print("")
for x6 in line_6:
    print(x6, end='')
    sys.stdout.flush()
    time.sleep(0.01)
print("")
for x7 in line_7:
    print(x7, end='')
    sys.stdout.flush()
    time.sleep(0.01)
print("")
for x8 in line_8:
    print(x8, end='')
    sys.stdout.flush()
    time.sleep(0.01)
print("")
time.sleep(1)
os.system('cls')
sys.exit()