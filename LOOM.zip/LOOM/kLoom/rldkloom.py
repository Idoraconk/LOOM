import pyautogui as bot 
import time

bot.PAUSE = 0.5
time.sleep(0.5)
bot.write('python kloom.py')
bot.press('enter')