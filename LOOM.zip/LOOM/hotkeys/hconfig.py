import pyautogui as bot 

bot.hotkey('win', 'i')