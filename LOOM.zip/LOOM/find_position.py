import pyautogui as bot

bot.sleep(5)
print(bot.position())