import pyautogui as bot
import os

bot.PAUSE = 0.02
os.system(':q')
os.system('python loom.py')