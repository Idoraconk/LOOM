def youtube():
    import webbrowser as web

    web.open('https://www.youtube.com/')
youtube()
