def micro():
   import pyautogui as bot 
   
   bot.PAUSE = 0.5
   bot.press('win')
   bot.write('microsoft edge')
   bot.press('enter')
micro()