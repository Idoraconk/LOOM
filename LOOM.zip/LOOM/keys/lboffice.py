def lboffice():
    import pyautogui as bot

    bot.PAUSE = 0.5
    bot.press('win')
    bot.write('libreoffice')
    bot.press('enter')
lboffice()
    
